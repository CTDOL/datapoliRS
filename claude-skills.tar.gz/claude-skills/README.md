# Skills de arquitetura para Claude Code

Quatro skills para desenvolver isolando a regra de negócio da stack. Feitas para ecossistema multi-stack, onde o sistema é o ativo e o framework é descartável.

## Instalação

```bash
# Pessoal — disponível em todos os projetos
cp -r arquitetura-hexagonal analise-legado api-design repo-bootstrap ~/.claude/skills/

# Ou por projeto
mkdir -p /caminho/do/projeto/.claude/skills
cp -r arquitetura-hexagonal /caminho/do/projeto/.claude/skills/
```

Torne os scripts executáveis:
```bash
chmod +x ~/.claude/skills/*/scripts/*.sh
```

Verifique no Claude Code com `/help` ou perguntando "quais skills você tem".

## As quatro

| Skill | Dispara quando | Núcleo |
|---|---|---|
| `arquitetura-hexagonal` | "onde isso deveria ficar", desenhar módulo, separar camadas | Portas e adaptadores, SOLID, DDD tático |
| `analise-legado` | "o que esse código faz", investigar bug, avaliar refatoração | Extrair regra, teste de caracterização, strangler fig |
| `api-design` | criar endpoint, definir contrato, integrar sistemas | API como adaptador de entrada |
| `repo-bootstrap` | projeto sem Git, configurar GitHub, montar CI | Credencial antes de remoto, CI útil |

Elas se referenciam entre si. `analise-legado` chama o detector de stack de `arquitetura-hexagonal`; `api-design` aponta para a camada anticorrupção em `ddd-estrategico.md`.

## Como o carregamento funciona

Disclosure progressivo, em três níveis:

1. Só `name` + `description` ficam sempre no contexto — poucos tokens por skill
2. O corpo do `SKILL.md` entra quando o Claude julga a skill relevante, ou quando você chama `/nome-da-skill`
3. `references/` só é lido se o corpo mandar ler

Por isso as referências podem ser extensas sem custo: DDD estratégico, por exemplo, só é carregado se o problema apresentar conflito real de vocabulário entre contextos.

## Scripts

Ambos são somente-leitura exceto onde indicado, e foram testados.

```bash
# Inventário: stack, git, testes, tamanho, sinais de acoplamento
arquitetura-hexagonal/scripts/detect-stack.sh /caminho/do/projeto

# Ponto de retorno: tar.gz datado + git init se necessário + varredura de credencial
analise-legado/scripts/snapshot.sh /caminho/do/projeto [destino-backup]
```

## Fluxo típico num sistema existente

```
snapshot.sh                    ponto de retorno
   ↓
detect-stack.sh                retrato do projeto
   ↓
analise-legado Fase 2          extrair as regras para uma lista
   ↓
teste de caracterização        congelar o comportamento atual
   ↓
arquitetura-hexagonal          propor a estrutura destino
   ↓
migrar um passo por commit     segurança → apresentação → persistência → caso de uso → domínio
```

## Nota sobre frontmatter

O frontmatter usa apenas `name` e `description`, que fazem parte do padrão aberto Agent Skills. Se um dia você adicionar campos específicos do Claude Code (como `allowed-tools`), a skill continua funcionando no Claude Code, mas o upload para claude.ai passa a falhar com erro de campo não permitido.

O `description` é o que decide se a skill é carregada — se uma delas não estiver disparando quando deveria, é o texto do `description` que precisa mudar, não o corpo.
